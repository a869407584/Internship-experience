/*进程创建*/

#include <stdio.h>
#include <unistd.h>

int gval = 100;
int main()
{
    printf("------head line-----pid:%d val:%d\n", getpid(), gval);
    pid_t pid = fork();
    if (pid < 0) {
        printf("fork error\n");
        return -1;
    }if (pid == 0) {
        //子进程单独运行这段代码，因为父进程返回的是子进程pid>0
        //所以不会进入这个判断
        gval = 20;
        printf("------child line-----pid:%d val:%d\n", getpid(), gval);
    }else {
        //只有父进程进入这个判断
        sleep(1);
        printf("------parent line-----pid:%d val:%d\n", getpid(), gval);
    }
    return 0;
}
