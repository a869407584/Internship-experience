#include <stdio.h>
void test_func() {
    printf("test func\n");
}
